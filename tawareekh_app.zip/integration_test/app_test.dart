import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:integration_test/integration_test.dart';
import '../lib/main.dart' as app;

void main() {
  IntegrationTestWidgetsFlutterBinding.ensureInitialized();

  group('اختبار تكامل التطبيق', () {
    testWidgets('اختبار تشغيل التطبيق والتنقل بين الشاشات', (WidgetTester tester) async {
      // تشغيل التطبيق
      app.main();
      await tester.pumpAndSettle();

      // التحقق من وجود الشاشة الرئيسية
      expect(find.text('تواريخ'), findsOneWidget);
      expect(find.text('إحصائياتك'), findsOneWidget);
      
      // التحقق من وجود أزرار القائمة الرئيسية
      expect(find.text('ابدأ اللعبة'), findsOneWidget);
      expect(find.text('إضافة حدث تاريخي'), findsOneWidget);
      expect(find.text('عرض الأحداث التاريخية'), findsOneWidget);
      expect(find.text('اختبار الذكاء الاصطناعي'), findsOneWidget);
      
      // اختبار الانتقال إلى شاشة الإعدادات
      await tester.tap(find.byIcon(Icons.settings));
      await tester.pumpAndSettle();
      expect(find.text('الإعدادات'), findsOneWidget);
      
      // العودة إلى الشاشة الرئيسية
      await tester.tap(find.byIcon(Icons.arrow_back));
      await tester.pumpAndSettle();
      
      // اختبار الانتقال إلى شاشة اللعبة
      await tester.tap(find.text('ابدأ اللعبة'));
      await tester.pumpAndSettle();
      
      // قد تظهر شاشة "لا توجد أحداث تاريخية" إذا كانت قاعدة البيانات فارغة
      if (find.text('لا توجد أحداث تاريخية').evaluate().isNotEmpty) {
        expect(find.text('لا توجد أحداث تاريخية'), findsOneWidget);
        await tester.tap(find.text('العودة للشاشة الرئيسية'));
        await tester.pumpAndSettle();
      } else {
        // إذا كانت هناك أحداث، نتحقق من وجود شاشة اللعبة
        expect(find.text('لعبة التواريخ'), findsOneWidget);
        await tester.tap(find.byIcon(Icons.arrow_back));
        await tester.pumpAndSettle();
      }
    });
  });
}
