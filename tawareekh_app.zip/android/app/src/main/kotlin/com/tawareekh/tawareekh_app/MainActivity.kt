package com.tawareekh.tawareekh_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
