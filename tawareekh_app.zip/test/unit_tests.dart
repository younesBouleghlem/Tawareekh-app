import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import '../lib/models/event_model.dart';
import '../lib/services/text_recognition_service.dart';
import '../lib/services/database_service.dart';
import 'package:provider/provider.dart';

void main() {
  group('اختبار نموذج الحدث التاريخي', () {
    test('إنشاء حدث تاريخي جديد', () {
      final event = HistoricalEvent(
        id: '1',
        title: 'فتح مكة',
        description: 'فتح المسلمون مكة بقيادة النبي محمد',
        date: DateTime(630, 1, 1),
        difficulty: 2,
      );
      
      expect(event.id, '1');
      expect(event.title, 'فتح مكة');
      expect(event.description, 'فتح المسلمون مكة بقيادة النبي محمد');
      expect(event.date.year, 630);
      expect(event.difficulty, 2);
    });
  });
  
  group('اختبار خدمة قاعدة البيانات', () {
    test('تحديث الحماسة', () {
      // هذا اختبار وهمي لتوضيح كيفية اختبار خدمة قاعدة البيانات
      // في التطبيق الفعلي، يجب استخدام قاعدة بيانات وهمية للاختبار
      
      final lastPlayedDate = DateTime(2025, 4, 17);
      final now = DateTime(2025, 4, 18);
      
      // التحقق مما إذا كان اليوم هو اليوم التالي ليوم آخر لعب
      final isNextDay = lastPlayedDate.year == now.year &&
                        lastPlayedDate.month == now.month &&
                        lastPlayedDate.day == now.day - 1;
      
      expect(isNextDay, true);
    });
  });
  
  group('اختبار خدمة التعرف على النصوص', () {
    test('تنسيق التاريخ', () {
      final service = TextRecognitionService();
      final date = DateTime(2023, 5, 15);
      
      // استخدام طريقة خاصة للاختبار
      final formattedDate = service._formatDate(date);
      
      expect(formattedDate, '15 مايو 2023');
    });
  });
}
