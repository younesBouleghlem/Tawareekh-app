import 'dart:io';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../services/text_recognition_service.dart';
import '../services/database_service.dart';
import '../models/event_model.dart';
import '../utils/app_theme.dart';
import 'package:uuid/uuid.dart';

/// شاشة إضافة حدث تاريخي جديد
/// تسمح للمستخدم بإضافة حدث تاريخي جديد عن طريق التقاط صورة أو اختيارها من المعرض
class AddEventScreen extends StatefulWidget {
  const AddEventScreen({Key? key}) : super(key: key);

  @override
  State<AddEventScreen> createState() => _AddEventScreenState();
}

class _AddEventScreenState extends State<AddEventScreen> {
  // متغيرات حالة الشاشة
  File? _selectedImage;
  bool _isProcessing = false;
  bool _isSuccess = false;
  String _errorMessage = '';
  
  // نموذج الحدث التاريخي
  HistoricalEvent? _event;
  
  // متحكمات النص
  final _titleController = TextEditingController();
  final _descriptionController = TextEditingController();
  final _dateController = TextEditingController();
  
  // مستوى الصعوبة
  int _difficulty = 1;

  @override
  void dispose() {
    _titleController.dispose();
    _descriptionController.dispose();
    _dateController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('إضافة حدث تاريخي'),
        centerTitle: true,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            // عنوان الشاشة والتعليمات
            const Text(
              'أضف حدثًا تاريخيًا جديدًا',
              style: TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.bold,
              ),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 8),
            const Text(
              'يمكنك إضافة حدث تاريخي عن طريق التقاط صورة أو اختيارها من المعرض، أو إدخال المعلومات يدويًا.',
              style: TextStyle(fontSize: 14),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 24),
            
            // عرض الصورة المختارة
            _buildImageSection(),
            const SizedBox(height: 24),
            
            // أزرار التقاط صورة أو اختيارها من المعرض
            _buildImagePickerButtons(),
            const SizedBox(height: 24),
            
            // نموذج إدخال بيانات الحدث التاريخي
            _buildEventForm(),
            const SizedBox(height: 24),
            
            // زر حفظ الحدث التاريخي
            _buildSaveButton(),
          ],
        ),
      ),
    );
  }

  // بناء قسم عرض الصورة
  Widget _buildImageSection() {
    return Container(
      height: 200,
      decoration: BoxDecoration(
        color: Colors.grey[200],
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: Colors.grey),
      ),
      child: _selectedImage != null
          ? ClipRRect(
              borderRadius: BorderRadius.circular(12),
              child: Image.file(
                _selectedImage!,
                fit: BoxFit.cover,
              ),
            )
          : const Center(
              child: Text(
                'لم يتم اختيار صورة',
                style: TextStyle(color: Colors.grey),
              ),
            ),
    );
  }

  // بناء أزرار التقاط صورة أو اختيارها من المعرض
  Widget _buildImagePickerButtons() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
      children: [
        ElevatedButton.icon(
          onPressed: _captureImage,
          icon: const Icon(Icons.camera_alt),
          label: const Text('التقاط صورة'),
          style: ElevatedButton.styleFrom(
            backgroundColor: AppTheme.primaryColor,
            foregroundColor: Colors.white,
          ),
        ),
        ElevatedButton.icon(
          onPressed: _pickImage,
          icon: const Icon(Icons.photo_library),
          label: const Text('اختيار من المعرض'),
          style: ElevatedButton.styleFrom(
            backgroundColor: AppTheme.secondaryColor,
            foregroundColor: Colors.white,
          ),
        ),
      ],
    );
  }

  // بناء نموذج إدخال بيانات الحدث التاريخي
  Widget _buildEventForm() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        // حقل التاريخ
        TextField(
          controller: _dateController,
          decoration: const InputDecoration(
            labelText: 'التاريخ',
            hintText: 'مثال: 15/05/1948',
            prefixIcon: Icon(Icons.calendar_today),
          ),
          keyboardType: TextInputType.datetime,
          textDirection: TextDirection.ltr,
        ),
        const SizedBox(height: 16),
        
        // حقل العنوان
        TextField(
          controller: _titleController,
          decoration: const InputDecoration(
            labelText: 'عنوان الحدث',
            hintText: 'أدخل عنوان الحدث التاريخي',
            prefixIcon: Icon(Icons.title),
          ),
        ),
        const SizedBox(height: 16),
        
        // حقل الوصف
        TextField(
          controller: _descriptionController,
          decoration: const InputDecoration(
            labelText: 'وصف الحدث',
            hintText: 'أدخل وصفًا للحدث التاريخي',
            prefixIcon: Icon(Icons.description),
          ),
          maxLines: 3,
        ),
        const SizedBox(height: 16),
        
        // اختيار مستوى الصعوبة
        const Text(
          'مستوى الصعوبة:',
          style: TextStyle(
            fontSize: 16,
            fontWeight: FontWeight.bold,
          ),
        ),
        const SizedBox(height: 8),
        Row(
          children: [
            _buildDifficultyOption(1, 'سهل'),
            const SizedBox(width: 16),
            _buildDifficultyOption(2, 'متوسط'),
            const SizedBox(width: 16),
            _buildDifficultyOption(3, 'صعب'),
          ],
        ),
      ],
    );
  }

  // بناء خيار مستوى الصعوبة
  Widget _buildDifficultyOption(int value, String label) {
    return Expanded(
      child: InkWell(
        onTap: () {
          setState(() {
            _difficulty = value;
          });
        },
        child: Container(
          padding: const EdgeInsets.symmetric(vertical: 8),
          decoration: BoxDecoration(
            color: _difficulty == value
                ? AppTheme.primaryColor
                : Colors.grey[300],
            borderRadius: BorderRadius.circular(8),
          ),
          child: Text(
            label,
            textAlign: TextAlign.center,
            style: TextStyle(
              color: _difficulty == value ? Colors.white : Colors.black,
              fontWeight: FontWeight.bold,
            ),
          ),
        ),
      ),
    );
  }

  // بناء زر حفظ الحدث التاريخي
  Widget _buildSaveButton() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        if (_errorMessage.isNotEmpty)
          Padding(
            padding: const EdgeInsets.only(bottom: 16),
            child: Text(
              _errorMessage,
              style: const TextStyle(
                color: Colors.red,
                fontWeight: FontWeight.bold,
              ),
              textAlign: TextAlign.center,
            ),
          ),
        if (_isSuccess)
          const Padding(
            padding: EdgeInsets.only(bottom: 16),
            child: Text(
              'تم حفظ الحدث التاريخي بنجاح!',
              style: TextStyle(
                color: Colors.green,
                fontWeight: FontWeight.bold,
              ),
              textAlign: TextAlign.center,
            ),
          ),
        ElevatedButton(
          onPressed: _isProcessing ? null : _saveEvent,
          style: ElevatedButton.styleFrom(
            backgroundColor: AppTheme.primaryColor,
            foregroundColor: Colors.white,
            padding: const EdgeInsets.symmetric(vertical: 16),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(12),
            ),
          ),
          child: _isProcessing
              ? const CircularProgressIndicator(color: Colors.white)
              : const Text(
                  'حفظ الحدث التاريخي',
                  style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                  ),
                ),
        ),
      ],
    );
  }

  // التقاط صورة من الكاميرا
  Future<void> _captureImage() async {
    final textRecognitionService =
        Provider.of<TextRecognitionService>(context, listen: false);
    
    final imageFile = await textRecognitionService.captureImage();
    if (imageFile != null) {
      setState(() {
        _selectedImage = imageFile;
        _isProcessing = true;
        _errorMessage = '';
      });
      
      await _processImage(imageFile);
    }
  }

  // اختيار صورة من المعرض
  Future<void> _pickImage() async {
    final textRecognitionService =
        Provider.of<TextRecognitionService>(context, listen: false);
    
    final imageFile = await textRecognitionService.pickImage();
    if (imageFile != null) {
      setState(() {
        _selectedImage = imageFile;
        _isProcessing = true;
        _errorMessage = '';
      });
      
      await _processImage(imageFile);
    }
  }

  // معالجة الصورة واستخراج النص منها
  Future<void> _processImage(File imageFile) async {
    try {
      final textRecognitionService =
          Provider.of<TextRecognitionService>(context, listen: false);
      
      final event = await textRecognitionService.analyzeImage(imageFile);
      
      if (event != null) {
        setState(() {
          _event = event;
          _titleController.text = event.title;
          _descriptionController.text = event.description;
          _dateController.text = _formatDate(event.date);
          _difficulty = event.difficulty;
          _isProcessing = false;
        });
      } else {
        setState(() {
          _errorMessage = 'لم يتم التعرف على تاريخ أو حدث في الصورة. يرجى المحاولة مرة أخرى أو إدخال البيانات يدويًا.';
          _isProcessing = false;
        });
      }
    } catch (e) {
      setState(() {
        _errorMessage = 'حدث خطأ أثناء معالجة الصورة: $e';
        _isProcessing = false;
      });
    }
  }

  // تنسيق التاريخ
  String _formatDate(DateTime date) {
    return '${date.day}/${date.month}/${date.year}';
  }

  // حفظ الحدث التاريخي
  Future<void> _saveEvent() async {
    if (_titleController.text.isEmpty) {
      setState(() {
        _errorMessage = 'يرجى إدخال عنوان الحدث';
      });
      return;
    }
    
    if (_dateController.text.isEmpty) {
      setState(() {
        _errorMessage = 'يرجى إدخال تاريخ الحدث';
      });
      return;
    }
    
    setState(() {
      _isProcessing = true;
      _errorMessage = '';
    });
    
    try {
      // تحليل التاريخ
      final dateStr = _dateController.text;
      final dateParts = dateStr.split(RegExp(r'[/.-]'));
      
      if (dateParts.length != 3) {
        throw Exception('صيغة التاريخ غير صحيحة');
      }
      
      final day = int.parse(dateParts[0]);
      final month = int.parse(dateParts[1]);
      final year = int.parse(dateParts[2]);
      
      final date = DateTime(year, month, day);
      
      // إنشاء كائن الحدث التاريخي
      final event = HistoricalEvent(
        id: _event?.id ?? const Uuid().v4(),
        date: date,
        title: _titleController.text,
        description: _descriptionController.text,
        difficulty: _difficulty,
      );
      
      // حفظ الحدث في قاعدة البيانات
      final databaseService =
          Provider.of<DatabaseService>(context, listen: false);
      await databaseService.insertEvent(event);
      
      setState(() {
        _isProcessing = false;
        _isSuccess = true;
        _errorMessage = '';
      });
      
      // إعادة تعيين النموذج بعد فترة قصيرة
      Future.delayed(const Duration(seconds: 2), () {
        if (mounted) {
          setState(() {
            _titleController.clear();
            _descriptionController.clear();
            _dateController.clear();
            _difficulty = 1;
            _selectedImage = null;
            _event = null;
            _isSuccess = false;
          });
        }
      });
    } catch (e) {
      setState(() {
        _isProcessing = false;
        _errorMessage = 'حدث خطأ أثناء حفظ الحدث: $e';
      });
    }
  }
}
