import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../services/database_service.dart';
import '../utils/app_theme.dart';
import '../widgets/score_widgets.dart';
import 'add_event_screen.dart';
import 'game_screen.dart';
import 'events_list_screen.dart';
import 'settings_screen.dart';
import 'ai_test_screen.dart';

/// الشاشة الرئيسية للتطبيق
/// تعرض القائمة الرئيسية مع الخيارات المتاحة للمستخدم
class HomeScreen extends StatefulWidget {
  const HomeScreen({Key? key}) : super(key: key);

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  // إحصائيات المستخدم
  Map<String, dynamic> _userStats = {};
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _loadUserStats();
  }

  // تحميل إحصائيات المستخدم من قاعدة البيانات
  Future<void> _loadUserStats() async {
    final databaseService = Provider.of<DatabaseService>(context, listen: false);
    final stats = await databaseService.getUserStats();
    
    setState(() {
      _userStats = stats;
      _isLoading = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('تواريخ'),
        centerTitle: true,
        actions: [
          IconButton(
            icon: const Icon(Icons.settings),
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => const SettingsScreen()),
              );
            },
          ),
        ],
      ),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : _buildHomeContent(),
    );
  }

  // بناء محتوى الشاشة الرئيسية
  Widget _buildHomeContent() {
    return Container(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          // عرض إحصائيات المستخدم
          _buildUserStatsCard(),
          const SizedBox(height: 24),
          
          // زر بدء اللعبة
          _buildMenuButton(
            title: 'ابدأ اللعبة',
            icon: Icons.play_arrow,
            color: AppTheme.primaryColor,
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => const GameScreen()),
              ).then((_) => _loadUserStats());
            },
          ),
          const SizedBox(height: 16),
          
          // زر إضافة حدث تاريخي
          _buildMenuButton(
            title: 'إضافة حدث تاريخي',
            icon: Icons.add_photo_alternate,
            color: AppTheme.secondaryColor,
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => const AddEventScreen()),
              );
            },
          ),
          const SizedBox(height: 16),
          
          // زر عرض الأحداث التاريخية
          _buildMenuButton(
            title: 'عرض الأحداث التاريخية',
            icon: Icons.history_edu,
            color: AppTheme.accentColor,
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => const EventsListScreen()),
              );
            },
          ),
          const SizedBox(height: 16),
          
          // زر اختبار الذكاء الاصطناعي
          _buildMenuButton(
            title: 'اختبار الذكاء الاصطناعي',
            icon: Icons.psychology,
            color: Colors.purple,
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => const AITestScreen()),
              );
            },
          ),
        ],
      ),
    );
  }

  // بناء بطاقة إحصائيات المستخدم
  Widget _buildUserStatsCard() {
    return Card(
      elevation: 4,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(16),
      ),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'إحصائياتك',
              style: TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 16),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                ScoreWidget(
                  score: _userStats['score'],
                  size: 1.2,
                ),
                StreakWidget(
                  streakDays: _userStats['streak_days'],
                  size: 1.2,
                ),
                _buildStatItem(
                  icon: Icons.check_circle,
                  title: 'الإجابات الصحيحة',
                  value: _userStats['correct_answers'].toString(),
                ),
              ],
            ),
            const SizedBox(height: 16),
            // مكافأة الحماسة
            if (_userStats['streak_days'] >= 3)
              const StreakBonusWidget(),
          ],
        ),
      ),
    );
  }

  // بناء عنصر إحصائية
  Widget _buildStatItem({
    required IconData icon,
    required String title,
    required String value,
  }) {
    return Column(
      children: [
        Icon(icon, size: 32, color: AppTheme.primaryColor),
        const SizedBox(height: 8),
        Text(
          title,
          style: const TextStyle(
            fontSize: 14,
            fontWeight: FontWeight.w500,
          ),
        ),
        const SizedBox(height: 4),
        Text(
          value,
          style: const TextStyle(
            fontSize: 18,
            fontWeight: FontWeight.bold,
          ),
        ),
      ],
    );
  }

  // بناء زر القائمة
  Widget _buildMenuButton({
    required String title,
    required IconData icon,
    required Color color,
    required VoidCallback onTap,
  }) {
    return ElevatedButton(
      onPressed: onTap,
      style: ElevatedButton.styleFrom(
        backgroundColor: color,
        foregroundColor: Colors.white,
        padding: const EdgeInsets.symmetric(vertical: 16),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(12),
        ),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(icon, size: 24),
          const SizedBox(width: 12),
          Text(
            title,
            style: const TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.bold,
            ),
          ),
        ],
      ),
    );
  }
}
