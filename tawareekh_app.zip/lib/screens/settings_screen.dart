import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../services/database_service.dart';
import '../utils/app_theme.dart';

/// شاشة الإعدادات
/// تتيح للمستخدم تعديل إعدادات التطبيق مثل مستوى الصعوبة الافتراضي وعدد الجولات
class SettingsScreen extends StatefulWidget {
  const SettingsScreen({Key? key}) : super(key: key);

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  // متغيرات الإعدادات
  int _defaultDifficulty = 1;
  int _totalRounds = 10;
  bool _isDarkMode = false;
  bool _isLoading = false;
  bool _isSaved = false;
  
  // إحصائيات المستخدم
  Map<String, dynamic> _userStats = {};

  @override
  void initState() {
    super.initState();
    _loadSettings();
    _loadUserStats();
  }

  // تحميل الإعدادات
  Future<void> _loadSettings() async {
    // في الإصدار الحالي، نستخدم قيم افتراضية
    // في المستقبل، يمكن تخزين الإعدادات في SharedPreferences
    setState(() {
      _defaultDifficulty = 1;
      _totalRounds = 10;
      _isDarkMode = Theme.of(context).brightness == Brightness.dark;
    });
  }

  // تحميل إحصائيات المستخدم
  Future<void> _loadUserStats() async {
    setState(() {
      _isLoading = true;
    });

    final databaseService = Provider.of<DatabaseService>(context, listen: false);
    final stats = await databaseService.getUserStats();
    
    setState(() {
      _userStats = stats;
      _isLoading = false;
    });
  }

  // حفظ الإعدادات
  Future<void> _saveSettings() async {
    setState(() {
      _isLoading = true;
    });

    // في الإصدار الحالي، لا نقوم بحفظ الإعدادات فعلياً
    // في المستقبل، يمكن حفظ الإعدادات في SharedPreferences
    
    // محاكاة تأخير الحفظ
    await Future.delayed(const Duration(milliseconds: 500));
    
    setState(() {
      _isLoading = false;
      _isSaved = true;
    });
    
    // إخفاء رسالة الحفظ بعد فترة قصيرة
    Future.delayed(const Duration(seconds: 2), () {
      if (mounted) {
        setState(() {
          _isSaved = false;
        });
      }
    });
  }

  // إعادة تعيين إحصائيات المستخدم
  Future<void> _resetStats() async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('تأكيد إعادة التعيين'),
        content: const Text('هل أنت متأكد من إعادة تعيين جميع الإحصائيات؟ لا يمكن التراجع عن هذا الإجراء.'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('إلغاء'),
          ),
          TextButton(
            onPressed: () => Navigator.pop(context, true),
            child: const Text('إعادة تعيين', style: TextStyle(color: Colors.red)),
          ),
        ],
      ),
    );
    
    if (confirmed == true) {
      setState(() {
        _isLoading = true;
      });

      final databaseService = Provider.of<DatabaseService>(context, listen: false);
      await databaseService.updateUserStats({
        'score': 0,
        'streak_days': 0,
        'last_played_date': DateTime.now().millisecondsSinceEpoch,
        'correct_answers': 0,
        'wrong_answers': 0
      });
      
      await _loadUserStats();
      
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('تم إعادة تعيين الإحصائيات بنجاح'),
          backgroundColor: Colors.green,
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('الإعدادات'),
        centerTitle: true,
      ),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : SingleChildScrollView(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // قسم إعدادات اللعبة
                  _buildSectionTitle('إعدادات اللعبة'),
                  const SizedBox(height: 16),
                  
                  // مستوى الصعوبة الافتراضي
                  _buildSettingItem(
                    title: 'مستوى الصعوبة الافتراضي',
                    child: _buildDifficultySelector(),
                  ),
                  const SizedBox(height: 16),
                  
                  // عدد الجولات
                  _buildSettingItem(
                    title: 'عدد الجولات',
                    child: _buildRoundsSelector(),
                  ),
                  const SizedBox(height: 24),
                  
                  // قسم المظهر
                  _buildSectionTitle('المظهر'),
                  const SizedBox(height: 16),
                  
                  // وضع الظلام
                  _buildSettingItem(
                    title: 'وضع الظلام',
                    child: Switch(
                      value: _isDarkMode,
                      onChanged: (value) {
                        setState(() {
                          _isDarkMode = value;
                        });
                      },
                      activeColor: AppTheme.primaryColor,
                    ),
                  ),
                  const SizedBox(height: 24),
                  
                  // قسم الإحصائيات
                  _buildSectionTitle('الإحصائيات'),
                  const SizedBox(height: 16),
                  
                  // بطاقة الإحصائيات
                  _buildStatsCard(),
                  const SizedBox(height: 16),
                  
                  // زر إعادة تعيين الإحصائيات
                  Center(
                    child: ElevatedButton.icon(
                      onPressed: _resetStats,
                      icon: const Icon(Icons.refresh),
                      label: const Text('إعادة تعيين الإحصائيات'),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.red,
                        foregroundColor: Colors.white,
                      ),
                    ),
                  ),
                  const SizedBox(height: 24),
                  
                  // زر حفظ الإعدادات
                  Center(
                    child: Column(
                      children: [
                        if (_isSaved)
                          const Padding(
                            padding: EdgeInsets.only(bottom: 8),
                            child: Text(
                              'تم حفظ الإعدادات بنجاح!',
                              style: TextStyle(
                                color: Colors.green,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ),
                        ElevatedButton.icon(
                          onPressed: _saveSettings,
                          icon: const Icon(Icons.save),
                          label: const Text('حفظ الإعدادات'),
                          style: ElevatedButton.styleFrom(
                            backgroundColor: AppTheme.primaryColor,
                            foregroundColor: Colors.white,
                            padding: const EdgeInsets.symmetric(
                              horizontal: 24,
                              vertical: 12,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 16),
                  
                  // معلومات التطبيق
                  const Center(
                    child: Text(
                      'تطبيق تواريخ - الإصدار 1.0.0',
                      style: TextStyle(
                        fontSize: 12,
                        color: Colors.grey,
                      ),
                    ),
                  ),
                ],
              ),
            ),
    );
  }

  // بناء عنوان قسم
  Widget _buildSectionTitle(String title) {
    return Text(
      title,
      style: const TextStyle(
        fontSize: 18,
        fontWeight: FontWeight.bold,
        color: AppTheme.primaryColor,
      ),
    );
  }

  // بناء عنصر إعداد
  Widget _buildSettingItem({
    required String title,
    required Widget child,
  }) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Theme.of(context).cardColor,
        borderRadius: BorderRadius.circular(12),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.05),
            blurRadius: 4,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Row(
        children: [
          Expanded(
            child: Text(
              title,
              style: const TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.w500,
              ),
            ),
          ),
          child,
        ],
      ),
    );
  }

  // بناء محدد مستوى الصعوبة
  Widget _buildDifficultySelector() {
    return SegmentedButton<int>(
      segments: const [
        ButtonSegment<int>(
          value: 1,
          label: Text('سهل'),
        ),
        ButtonSegment<int>(
          value: 2,
          label: Text('متوسط'),
        ),
        ButtonSegment<int>(
          value: 3,
          label: Text('صعب'),
        ),
      ],
      selected: {_defaultDifficulty},
      onSelectionChanged: (Set<int> newSelection) {
        setState(() {
          _defaultDifficulty = newSelection.first;
        });
      },
      style: ButtonStyle(
        backgroundColor: MaterialStateProperty.resolveWith<Color>(
          (Set<MaterialState> states) {
            if (states.contains(MaterialState.selected)) {
              return AppTheme.primaryColor;
            }
            return Colors.transparent;
          },
        ),
        foregroundColor: MaterialStateProperty.resolveWith<Color>(
          (Set<MaterialState> states) {
            if (states.contains(MaterialState.selected)) {
              return Colors.white;
            }
            return AppTheme.primaryColor;
          },
        ),
      ),
    );
  }

  // بناء محدد عدد الجولات
  Widget _buildRoundsSelector() {
    return Row(
      children: [
        IconButton(
          onPressed: () {
            if (_totalRounds > 5) {
              setState(() {
                _totalRounds -= 5;
              });
            }
          },
          icon: const Icon(Icons.remove),
          color: AppTheme.primaryColor,
        ),
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
          decoration: BoxDecoration(
            color: AppTheme.primaryColor.withOpacity(0.1),
            borderRadius: BorderRadius.circular(8),
          ),
          child: Text(
            '$_totalRounds',
            style: const TextStyle(
              fontSize: 16,
              fontWeight: FontWeight.bold,
            ),
          ),
        ),
        IconButton(
          onPressed: () {
            if (_totalRounds < 20) {
              setState(() {
                _totalRounds += 5;
              });
            }
          },
          icon: const Icon(Icons.add),
          color: AppTheme.primaryColor,
        ),
      ],
    );
  }

  // بناء بطاقة الإحصائيات
  Widget _buildStatsCard() {
    return Card(
      elevation: 2,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12),
      ),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // النقاط
            _buildStatRow(
              icon: Icons.emoji_events,
              title: 'النقاط',
              value: _userStats['score'].toString(),
            ),
            const SizedBox(height: 12),
            
            // الحماسة
            _buildStatRow(
              icon: Icons.local_fire_department,
              title: 'الحماسة',
              value: '${_userStats['streak_days']} يوم',
            ),
            const SizedBox(height: 12),
            
            // الإجابات الصحيحة
            _buildStatRow(
              icon: Icons.check_circle,
              title: 'الإجابات الصحيحة',
              value: _userStats['correct_answers'].toString(),
            ),
            const SizedBox(height: 12),
            
            // الإجابات الخاطئة
            _buildStatRow(
              icon: Icons.cancel,
              title: 'الإجابات الخاطئة',
              value: _userStats['wrong_answers'].toString(),
            ),
          ],
        ),
      ),
    );
  }

  // بناء صف إحصائية
  Widget _buildStatRow({
    required IconData icon,
    required String title,
    required String value,
  }) {
    return Row(
      children: [
        Icon(icon, color: AppTheme.primaryColor),
        const SizedBox(width: 12),
        Text(
          title,
          style: const TextStyle(fontSize: 14),
        ),
        const Spacer(),
        Text(
          value,
          style: const TextStyle(
            fontSize: 16,
            fontWeight: FontWeight.bold,
          ),
        ),
      ],
    );
  }
}
