import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'dart:math';
import '../services/database_service.dart';
import '../services/text_recognition_service.dart';
import '../models/event_model.dart';
import '../utils/app_theme.dart';
import '../widgets/explanation_dialog.dart';

/// شاشة اللعبة الرئيسية
/// تعرض أسئلة عن الأحداث التاريخية وتتيح للمستخدم اختيار الإجابة الصحيحة
class GameScreen extends StatefulWidget {
  const GameScreen({Key? key}) : super(key: key);

  @override
  State<GameScreen> createState() => _GameScreenState();
}

class _GameScreenState extends State<GameScreen> with SingleTickerProviderStateMixin {
  // متغيرات حالة اللعبة
  bool _isLoading = true;
  bool _isGameOver = false;
  bool _noEventsFound = false;
  int _currentRound = 0;
  int _totalRounds = 10;
  int _selectedDifficulty = 1; // 1 = سهل، 2 = متوسط، 3 = صعب
  
  // متغيرات السؤال الحالي
  HistoricalEvent? _currentEvent;
  List<String> _options = [];
  int? _selectedOption;
  bool _showResult = false;
  bool _isCorrect = false;
  
  // إحصائيات اللعبة
  int _correctAnswers = 0;
  int _wrongAnswers = 0;
  int _currentScore = 0;
  int _streakDays = 0;
  
  // قائمة الأحداث التاريخية
  List<HistoricalEvent> _events = [];
  List<HistoricalEvent> _usedEvents = [];
  
  // مولد الأرقام العشوائية
  final Random _random = Random();
  
  // متحكم الرسوم المتحركة
  late AnimationController _animationController;
  late Animation<double> _animation;

  @override
  void initState() {
    super.initState();
    
    // إعداد الرسوم المتحركة
    _animationController = AnimationController(
      duration: const Duration(milliseconds: 500),
      vsync: this,
    );
    
    _animation = CurvedAnimation(
      parent: _animationController,
      curve: Curves.easeInOut,
    );
    
    _loadSettings();
    _loadEvents();
  }
  
  @override
  void dispose() {
    _animationController.dispose();
    super.dispose();
  }

  // تحميل الإعدادات
  Future<void> _loadSettings() async {
    // في الإصدار الحالي، نستخدم قيم افتراضية
    // في المستقبل، يمكن تحميل الإعدادات من SharedPreferences
    setState(() {
      _selectedDifficulty = 1;
      _totalRounds = 10;
    });
    
    // تحميل إحصائيات المستخدم
    final databaseService = Provider.of<DatabaseService>(context, listen: false);
    final stats = await databaseService.getUserStats();
    
    setState(() {
      _currentScore = stats['score'];
      _streakDays = stats['streak_days'];
    });
  }

  // تحميل الأحداث التاريخية من قاعدة البيانات
  Future<void> _loadEvents() async {
    setState(() {
      _isLoading = true;
    });

    final databaseService = Provider.of<DatabaseService>(context, listen: false);
    
    try {
      // تحميل الأحداث من جميع مستويات الصعوبة
      final events = await databaseService.getEvents();
      
      if (events.isEmpty) {
        setState(() {
          _isLoading = false;
          _noEventsFound = true;
        });
        return;
      }
      
      setState(() {
        _events = events;
        _isLoading = false;
        _noEventsFound = false;
      });
      
      // بدء الجولة الأولى
      _startNewRound();
      
      // تحديث الحماسة (streak)
      await databaseService.updateStreak();
      
      // تحديث إحصائيات المستخدم
      final stats = await databaseService.getUserStats();
      setState(() {
        _streakDays = stats['streak_days'];
      });
    } catch (e) {
      setState(() {
        _isLoading = false;
      });
      
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('حدث خطأ أثناء تحميل الأحداث: $e'),
          backgroundColor: Colors.red,
        ),
      );
    }
  }

  // بدء جولة جديدة
  void _startNewRound() {
    if (_currentRound >= _totalRounds || _events.isEmpty) {
      setState(() {
        _isGameOver = true;
      });
      return;
    }
    
    // تصفية الأحداث حسب مستوى الصعوبة
    List<HistoricalEvent> filteredEvents = _events.where((event) {
      // في المستوى السهل، نستخدم فقط الأحداث السهلة
      if (_selectedDifficulty == 1) {
        return event.difficulty == 1;
      }
      // في المستوى المتوسط، نستخدم الأحداث السهلة والمتوسطة
      else if (_selectedDifficulty == 2) {
        return event.difficulty <= 2;
      }
      // في المستوى الصعب، نستخدم جميع الأحداث
      else {
        return true;
      }
    }).toList();
    
    // إذا لم تكن هناك أحداث متاحة، نستخدم جميع الأحداث
    if (filteredEvents.isEmpty) {
      filteredEvents = _events;
    }
    
    // استبعاد الأحداث المستخدمة سابقاً إذا كان ذلك ممكناً
    filteredEvents = filteredEvents.where((event) => !_usedEvents.contains(event)).toList();
    
    // إذا لم تكن هناك أحداث متاحة، نعيد استخدام جميع الأحداث
    if (filteredEvents.isEmpty) {
      filteredEvents = _events;
      _usedEvents.clear();
    }
    
    // اختيار حدث عشوائي
    final eventIndex = _random.nextInt(filteredEvents.length);
    final event = filteredEvents[eventIndex];
    
    // إضافة الحدث إلى قائمة الأحداث المستخدمة
    _usedEvents.add(event);
    
    // إنشاء خيارات للسؤال
    final options = _generateOptions(event);
    
    setState(() {
      _currentEvent = event;
      _options = options;
      _selectedOption = null;
      _showResult = false;
      _currentRound++;
    });
    
    // تشغيل الرسوم المتحركة
    _animationController.reset();
    _animationController.forward();
  }

  // إنشاء خيارات للسؤال
  List<String> _generateOptions(HistoricalEvent correctEvent) {
    // نوع السؤال: 0 = اختر التاريخ الصحيح، 1 = اختر الحدث الصحيح
    final questionType = _random.nextInt(2);
    
    if (questionType == 0) {
      // اختر التاريخ الصحيح
      final correctDate = _formatDate(correctEvent.date);
      final options = <String>[correctDate];
      
      // إنشاء 3 تواريخ عشوائية مختلفة
      while (options.length < 4) {
        // تحديد نطاق التواريخ العشوائية بناءً على مستوى الصعوبة
        int yearRange = 10;
        if (_selectedDifficulty == 2) yearRange = 5;
        if (_selectedDifficulty == 3) yearRange = 3;
        
        final year = correctEvent.date.year + _random.nextInt(yearRange * 2) - yearRange;
        final month = 1 + _random.nextInt(12);
        final day = 1 + _random.nextInt(28);
        
        final randomDate = DateTime(year, month, day);
        final formattedDate = _formatDate(randomDate);
        
        if (!options.contains(formattedDate)) {
          options.add(formattedDate);
        }
      }
      
      // ترتيب الخيارات عشوائياً
      options.shuffle();
      return options;
    } else {
      // اختر الحدث الصحيح
      final correctTitle = correctEvent.title;
      final options = <String>[correctTitle];
      
      // اختيار 3 أحداث عشوائية مختلفة
      final availableEvents = List<HistoricalEvent>.from(_events)
        ..removeWhere((e) => e.id == correctEvent.id);
      
      if (availableEvents.length >= 3) {
        availableEvents.shuffle();
        for (int i = 0; i < 3; i++) {
          options.add(availableEvents[i].title);
        }
      } else {
        // إذا لم يكن هناك ما يكفي من الأحداث، إنشاء عناوين عشوائية
        final fakeTitles = [
          'اكتشاف أمريكا',
          'معركة حطين',
          'سقوط الأندلس',
          'فتح القسطنطينية',
          'الثورة الفرنسية',
          'الحرب العالمية الأولى',
          'استقلال الهند',
          'اختراع الطباعة',
          'بناء سور الصين العظيم',
          'تأسيس الأمم المتحدة',
          'اكتشاف الكهرباء',
          'أول رحلة إلى القمر',
          'اختراع الإنترنت',
          'سقوط جدار برلين',
          'تأسيس منظمة الأمم المتحدة',
        ];
        
        fakeTitles.shuffle();
        
        for (int i = 0; i < 3; i++) {
          if (!options.contains(fakeTitles[i])) {
            options.add(fakeTitles[i]);
          }
        }
      }
      
      // ترتيب الخيارات عشوائياً
      options.shuffle();
      return options;
    }
  }

  // التحقق من الإجابة
  Future<void> _checkAnswer(int optionIndex) async {
    if (_showResult) return;
    
    final selectedOption = _options[optionIndex];
    final isCorrect = _isCorrectAnswer(selectedOption);
    
    setState(() {
      _selectedOption = optionIndex;
      _showResult = true;
      _isCorrect = isCorrect;
    });
    
    // تحديث الإحصائيات
    if (isCorrect) {
      _correctAnswers++;
      
      // زيادة النقاط بناءً على مستوى الصعوبة
      int points = 10;
      if (_selectedDifficulty == 2) points = 15;
      if (_selectedDifficulty == 3) points = 20;
      
      _currentScore += points;
    } else {
      _wrongAnswers++;
    }
    
    // تحديث النقاط في قاعدة البيانات
    final databaseService = Provider.of<DatabaseService>(context, listen: false);
    await databaseService.updateScore(isCorrect);
    
    // الانتقال إلى الجولة التالية بعد فترة قصيرة
    Future.delayed(const Duration(seconds: 2), () {
      if (mounted) {
        _startNewRound();
      }
    });
  }

  // التحقق مما إذا كانت الإجابة صحيحة
  bool _isCorrectAnswer(String selectedOption) {
    if (_currentEvent == null) return false;
    
    // نوع السؤال: 0 = اختر التاريخ الصحيح، 1 = اختر الحدث الصحيح
    final questionType = _getQuestionType();
    
    if (questionType == 0) {
      // اختر التاريخ الصحيح
      return selectedOption == _formatDate(_currentEvent!.date);
    } else {
      // اختر الحدث الصحيح
      return selectedOption == _currentEvent!.title;
    }
  }

  // الحصول على نوع السؤال الحالي
  int _getQuestionType() {
    if (_currentEvent == null || _options.isEmpty) return 0;
    
    // التحقق مما إذا كان السؤال عن التاريخ أو الحدث
    return _options.contains(_currentEvent!.title) ? 1 : 0;
  }
  
  // عرض شرح الحدث أو التاريخ
  void _showExplanation() {
    if (_currentEvent == null) return;
    
    final textRecognitionService = Provider.of<TextRecognitionService>(context, listen: false);
    final explanation = textRecognitionService.generateSimpleExplanation(_currentEvent!);
    
    showDialog(
      context: context,
      builder: (context) => ExplanationDialog(
        event: _currentEvent!,
        explanation: explanation,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('لعبة التواريخ'),
        centerTitle: true,
      ),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : _noEventsFound
              ? _buildNoEventsFound()
              : _isGameOver
                  ? _buildGameOver()
                  : _buildGameContent(),
    );
  }

  // بناء محتوى اللعبة
  Widget _buildGameContent() {
    return Container(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          // معلومات الجولة
          _buildRoundInfo(),
          const SizedBox(height: 24),
          
          // السؤال
          FadeTransition(
            opacity: _animation,
            child: SlideTransition(
              position: Tween<Offset>(
                begin: const Offset(0.1, 0),
                end: Offset.zero,
              ).animate(_animation),
              child: _buildQuestion(),
            ),
          ),
          const SizedBox(height: 24),
          
          // الخيارات
          ..._buildOptions(),
          
          // نتيجة الإجابة
          if (_showResult) ...[
            const SizedBox(height: 24),
            _buildAnswerResult(),
          ],
        ],
      ),
    );
  }

  // بناء معلومات الجولة
  Widget _buildRoundInfo() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        // رقم الجولة
        Text(
          'الجولة: $_currentRound / $_totalRounds',
          style: const TextStyle(
            fontSize: 16,
            fontWeight: FontWeight.bold,
          ),
        ),
        
        // النقاط الحالية
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
          decoration: BoxDecoration(
            color: AppTheme.primaryColor.withOpacity(0.2),
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: AppTheme.primaryColor),
          ),
          child: Row(
            children: [
              const Icon(Icons.emoji_events, size: 16, color: AppTheme.primaryColor),
              const SizedBox(width: 4),
              Text(
                '$_currentScore نقطة',
                style: const TextStyle(
                  fontSize: 14,
                  fontWeight: FontWeight.bold,
                  color: AppTheme.primaryColor,
                ),
              ),
            ],
          ),
        ),
        
        // مستوى الصعوبة
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
          decoration: BoxDecoration(
            color: _getDifficultyColor().withOpacity(0.2),
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: _getDifficultyColor()),
          ),
          child: Text(
            _getDifficultyLabel(),
            style: TextStyle(
              fontSize: 14,
              fontWeight: FontWeight.bold,
              color: _getDifficultyColor(),
            ),
          ),
        ),
      ],
    );
  }

  // بناء السؤال
  Widget _buildQuestion() {
    if (_currentEvent == null) return const SizedBox();
    
    // نوع السؤال: 0 = اختر التاريخ الصحيح، 1 = اختر الحدث الصحيح
    final questionType = _getQuestionType();
    
    return Card(
      elevation: 4,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(16),
      ),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // عنوان السؤال
            Row(
              children: [
                Expanded(
                  child: Text(
                    questionType == 0
                        ? 'ما هو التاريخ الصحيح للحدث التالي؟'
                        : 'ما هو الحدث الذي وقع في التاريخ التالي؟',
                    style: const TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
                // زر الشرح
                IconButton(
                  onPressed: _showExplanation,
                  icon: const Icon(Icons.info_outline),
                  tooltip: 'شرح',
                  color: AppTheme.primaryColor,
                ),
              ],
            ),
            const SizedBox(height: 16),
            
            // محتوى السؤال
            Text(
              questionType == 0
                  ? _currentEvent!.title
                  : _formatDate(_currentEvent!.date),
              style: const TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.bold,
              ),
            ),
            
            // وصف الحدث (يظهر فقط في نوع السؤال 0)
            if (questionType == 0 && _currentEvent!.description.isNotEmpty) ...[
              const SizedBox(height: 8),
              Text(
                _currentEvent!.description,
                style: const TextStyle(fontSize: 14),
              ),
            ],
          ],
        ),
      ),
    );
  }

  // بناء الخيارات
  List<Widget> _buildOptions() {
    final List<Widget> optionWidgets = [];
    
    for (int i = 0; i < _options.length; i++) {
      final option = _options[i];
      
      // تحديد لون الخيار
      Color color = Colors.grey[300]!;
      Color textColor = Colors.black;
      
      if (_showResult) {
        if (_isCorrectAnswer(option)) {
          color = Colors.green;
          textColor = Colors.white;
        } else if (_selectedOption == i) {
          color = Colors.red;
          textColor = Colors.white;
        }
      } else if (_selectedOption == i) {
        color = AppTheme.primaryColor;
        textColor = Colors.white;
      }
      
      final optionWidget = Padding(
        padding: const EdgeInsets.only(bottom: 12),
        child: ElevatedButton(
          onPressed: _showResult ? null : () => _checkAnswer(i),
          style: ElevatedButton.styleFrom(
            backgroundColor: color,
            foregroundColor: textColor,
            padding: const EdgeInsets.symmetric(vertical: 16, horizontal: 16),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(12),
            ),
          ),
          child: Text(
            option,
            style: TextStyle(
              fontSize: 16,
              fontWeight: FontWeight.bold,
              color: textColor,
            ),
          ),
        ),
      );
      
      optionWidgets.add(optionWidget);
    }
    
    return optionWidgets;
  }

  // بناء نتيجة الإجابة
  Widget _buildAnswerResult() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: _isCorrect ? Colors.green.withOpacity(0.2) : Colors.red.withOpacity(0.2),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: _isCorrect ? Colors.green : Colors.red,
        ),
      ),
      child: Column(
        children: [
          Text(
            _isCorrect ? 'إجابة صحيحة!' : 'إجابة خاطئة!',
            style: TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.bold,
              color: _isCorrect ? Colors.green : Colors.red,
            ),
          ),
          const SizedBox(height: 8),
          Text(
            _isCorrect
                ? 'أحسنت! لقد حصلت على ${_selectedDifficulty == 1 ? 10 : _selectedDifficulty == 2 ? 15 : 20} نقطة إضافية.'
                : 'الإجابة الصحيحة هي: ${_getCorrectAnswer()}',
            style: TextStyle(
              fontSize: 14,
              color: _isCorrect ? Colors.green : Colors.red,
            ),
            textAlign: TextAlign.center,
          ),
        ],
      ),
    );
  }

  // بناء شاشة انتهاء اللعبة
  Widget _buildGameOver() {
    return Container(
      padding: const EdgeInsets.all(24),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          // عنوان انتهاء اللعبة
          const Text(
            'انتهت اللعبة!',
            style: TextStyle(
              fontSize: 28,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 24),
          
          // إحصائيات اللعبة
          Card(
            elevation: 4,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(16),
            ),
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                children: [
                  const Text(
                    'النتائج',
                    style: TextStyle(
                      fontSize: 20,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const SizedBox(height: 16),
                  
                  // الإجابات الصحيحة
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      const Text(
                        'الإجابات الصحيحة:',
                        style: TextStyle(fontSize: 16),
                      ),
                      Text(
                        '$_correctAnswers',
                        style: const TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.bold,
                          color: Colors.green,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 8),
                  
                  // الإجابات الخاطئة
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      const Text(
                        'الإجابات الخاطئة:',
                        style: TextStyle(fontSize: 16),
                      ),
                      Text(
                        '$_wrongAnswers',
                        style: const TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.bold,
                          color: Colors.red,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 8),
                  
                  // النقاط المكتسبة
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      const Text(
                        'النقاط المكتسبة:',
                        style: TextStyle(fontSize: 16),
                      ),
                      Text(
                        '$_currentScore',
                        style: const TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.bold,
                          color: AppTheme.primaryColor,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 8),
                  
                  // الحماسة
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      const Text(
                        'الحماسة:',
                        style: TextStyle(fontSize: 16),
                      ),
                      Row(
                        children: [
                          const Icon(Icons.local_fire_department, color: Colors.orange, size: 20),
                          const SizedBox(width: 4),
                          Text(
                            '$_streakDays يوم',
                            style: const TextStyle(
                              fontSize: 16,
                              fontWeight: FontWeight.bold,
                              color: Colors.orange,
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                  const SizedBox(height: 8),
                  
                  // نسبة الإجابات الصحيحة
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      const Text(
                        'نسبة الإجابات الصحيحة:',
                        style: TextStyle(fontSize: 16),
                      ),
                      Text(
                        '${(_correctAnswers / _totalRounds * 100).toStringAsFixed(1)}%',
                        style: TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.bold,
                          color: _correctAnswers > _wrongAnswers ? Colors.green : Colors.red,
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 32),
          
          // أزرار الإجراءات
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
              // زر العودة للشاشة الرئيسية
              ElevatedButton.icon(
                onPressed: () {
                  Navigator.pop(context);
                },
                icon: const Icon(Icons.home),
                label: const Text('الرئيسية'),
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.grey,
                  foregroundColor: Colors.white,
                ),
              ),
              
              // زر إعادة اللعب
              ElevatedButton.icon(
                onPressed: () {
                  setState(() {
                    _currentRound = 0;
                    _correctAnswers = 0;
                    _wrongAnswers = 0;
                    _isGameOver = false;
                    _usedEvents.clear();
                  });
                  _startNewRound();
                },
                icon: const Icon(Icons.replay),
                label: const Text('إعادة اللعب'),
                style: ElevatedButton.styleFrom(
                  backgroundColor: AppTheme.primaryColor,
                  foregroundColor: Colors.white,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  // بناء شاشة عدم وجود أحداث
  Widget _buildNoEventsFound() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(
            Icons.history_edu,
            size: 64,
            color: Colors.grey[400],
          ),
          const SizedBox(height: 16),
          const Text(
            'لا توجد أحداث تاريخية',
            style: TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.bold,
              color: Colors.grey,
            ),
          ),
          const SizedBox(height: 8),
          const Text(
            'أضف أحداثًا تاريخية جديدة لبدء اللعبة',
            style: TextStyle(
              fontSize: 14,
              color: Colors.grey,
            ),
          ),
          const SizedBox(height: 24),
          ElevatedButton.icon(
            onPressed: () {
              Navigator.pop(context);
            },
            icon: const Icon(Icons.arrow_back),
            label: const Text('العودة للشاشة الرئيسية'),
            style: ElevatedButton.styleFrom(
              backgroundColor: AppTheme.primaryColor,
              foregroundColor: Colors.white,
            ),
          ),
        ],
      ),
    );
  }

  // الحصول على الإجابة الصحيحة
  String _getCorrectAnswer() {
    if (_currentEvent == null) return '';
    
    // نوع السؤال: 0 = اختر التاريخ الصحيح، 1 = اختر الحدث الصحيح
    final questionType = _getQuestionType();
    
    if (questionType == 0) {
      // اختر التاريخ الصحيح
      return _formatDate(_currentEvent!.date);
    } else {
      // اختر الحدث الصحيح
      return _currentEvent!.title;
    }
  }

  // تنسيق التاريخ
  String _formatDate(DateTime date) {
    final List<String> arabicMonths = [
      'يناير', 'فبراير', 'مارس', 'إبريل', 'مايو', 'يونيو',
      'يوليو', 'أغسطس', 'سبتمبر', 'أكتوبر', 'نوفمبر', 'ديسمبر'
    ];
    
    return '${date.day} ${arabicMonths[date.month - 1]} ${date.year}';
  }

  // الحصول على لون مستوى الصعوبة
  Color _getDifficultyColor() {
    switch (_selectedDifficulty) {
      case 1:
        return Colors.green;
      case 2:
        return Colors.orange;
      case 3:
        return Colors.red;
      default:
        return Colors.grey;
    }
  }

  // الحصول على تسمية مستوى الصعوبة
  String _getDifficultyLabel() {
    switch (_selectedDifficulty) {
      case 1:
        return 'سهل';
      case 2:
        return 'متوسط';
      case 3:
        return 'صعب';
      default:
        return 'غير محدد';
    }
  }
}
