import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../services/database_service.dart';
import '../models/event_model.dart';
import '../utils/app_theme.dart';

/// شاشة عرض قائمة الأحداث التاريخية
/// تعرض جميع الأحداث التاريخية المخزنة في قاعدة البيانات
class EventsListScreen extends StatefulWidget {
  const EventsListScreen({Key? key}) : super(key: key);

  @override
  State<EventsListScreen> createState() => _EventsListScreenState();
}

class _EventsListScreenState extends State<EventsListScreen> {
  List<HistoricalEvent> _events = [];
  bool _isLoading = true;
  int _selectedDifficulty = 0; // 0 = الكل، 1 = سهل، 2 = متوسط، 3 = صعب

  @override
  void initState() {
    super.initState();
    _loadEvents();
  }

  // تحميل الأحداث التاريخية من قاعدة البيانات
  Future<void> _loadEvents() async {
    setState(() {
      _isLoading = true;
    });

    final databaseService = Provider.of<DatabaseService>(context, listen: false);
    
    try {
      List<HistoricalEvent> events;
      
      if (_selectedDifficulty == 0) {
        events = await databaseService.getEvents();
      } else {
        events = await databaseService.getEventsByDifficulty(_selectedDifficulty);
      }
      
      setState(() {
        _events = events;
        _isLoading = false;
      });
    } catch (e) {
      setState(() {
        _isLoading = false;
      });
      
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('حدث خطأ أثناء تحميل الأحداث: $e'),
          backgroundColor: Colors.red,
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('الأحداث التاريخية'),
        centerTitle: true,
      ),
      body: Column(
        children: [
          // شريط تصفية الأحداث حسب مستوى الصعوبة
          _buildFilterBar(),
          
          // قائمة الأحداث التاريخية
          Expanded(
            child: _isLoading
                ? const Center(child: CircularProgressIndicator())
                : _events.isEmpty
                    ? _buildEmptyState()
                    : _buildEventsList(),
          ),
        ],
      ),
    );
  }

  // بناء شريط تصفية الأحداث حسب مستوى الصعوبة
  Widget _buildFilterBar() {
    return Container(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'تصفية حسب مستوى الصعوبة:',
            style: TextStyle(
              fontSize: 16,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 8),
          Row(
            children: [
              _buildFilterOption(0, 'الكل'),
              const SizedBox(width: 8),
              _buildFilterOption(1, 'سهل'),
              const SizedBox(width: 8),
              _buildFilterOption(2, 'متوسط'),
              const SizedBox(width: 8),
              _buildFilterOption(3, 'صعب'),
            ],
          ),
        ],
      ),
    );
  }

  // بناء خيار تصفية
  Widget _buildFilterOption(int value, String label) {
    return Expanded(
      child: InkWell(
        onTap: () {
          setState(() {
            _selectedDifficulty = value;
          });
          _loadEvents();
        },
        child: Container(
          padding: const EdgeInsets.symmetric(vertical: 8),
          decoration: BoxDecoration(
            color: _selectedDifficulty == value
                ? AppTheme.primaryColor
                : Colors.grey[300],
            borderRadius: BorderRadius.circular(8),
          ),
          child: Text(
            label,
            textAlign: TextAlign.center,
            style: TextStyle(
              color: _selectedDifficulty == value ? Colors.white : Colors.black,
              fontWeight: FontWeight.bold,
            ),
          ),
        ),
      ),
    );
  }

  // بناء حالة فارغة عندما لا توجد أحداث
  Widget _buildEmptyState() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(
            Icons.history_edu,
            size: 64,
            color: Colors.grey[400],
          ),
          const SizedBox(height: 16),
          const Text(
            'لا توجد أحداث تاريخية',
            style: TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.bold,
              color: Colors.grey,
            ),
          ),
          const SizedBox(height: 8),
          const Text(
            'أضف أحداثًا تاريخية جديدة لتظهر هنا',
            style: TextStyle(
              fontSize: 14,
              color: Colors.grey,
            ),
          ),
          const SizedBox(height: 24),
          ElevatedButton.icon(
            onPressed: () {
              Navigator.pop(context);
            },
            icon: const Icon(Icons.arrow_back),
            label: const Text('العودة للشاشة الرئيسية'),
            style: ElevatedButton.styleFrom(
              backgroundColor: AppTheme.primaryColor,
              foregroundColor: Colors.white,
            ),
          ),
        ],
      ),
    );
  }

  // بناء قائمة الأحداث التاريخية
  Widget _buildEventsList() {
    return ListView.builder(
      padding: const EdgeInsets.all(16),
      itemCount: _events.length,
      itemBuilder: (context, index) {
        final event = _events[index];
        return _buildEventCard(event);
      },
    );
  }

  // بناء بطاقة حدث تاريخي
  Widget _buildEventCard(HistoricalEvent event) {
    return Card(
      margin: const EdgeInsets.only(bottom: 16),
      elevation: 2,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12),
      ),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // عنوان الحدث ومستوى الصعوبة
            Row(
              children: [
                Expanded(
                  child: Text(
                    event.title,
                    style: const TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
                _buildDifficultyBadge(event.difficulty),
              ],
            ),
            const SizedBox(height: 8),
            
            // تاريخ الحدث
            Row(
              children: [
                const Icon(Icons.calendar_today, size: 16, color: Colors.grey),
                const SizedBox(width: 8),
                Text(
                  _formatDate(event.date),
                  style: const TextStyle(
                    fontSize: 14,
                    color: Colors.grey,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 8),
            
            // وصف الحدث
            if (event.description.isNotEmpty) ...[
              const Divider(),
              Text(
                event.description,
                style: const TextStyle(fontSize: 14),
              ),
            ],
            
            // أزرار الإجراءات
            const SizedBox(height: 16),
            Row(
              mainAxisAlignment: MainAxisAlignment.end,
              children: [
                // زر الحذف
                IconButton(
                  onPressed: () => _deleteEvent(event),
                  icon: const Icon(Icons.delete, color: Colors.red),
                  tooltip: 'حذف',
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  // بناء شارة مستوى الصعوبة
  Widget _buildDifficultyBadge(int difficulty) {
    Color color;
    String label;
    
    switch (difficulty) {
      case 1:
        color = Colors.green;
        label = 'سهل';
        break;
      case 2:
        color = Colors.orange;
        label = 'متوسط';
        break;
      case 3:
        color = Colors.red;
        label = 'صعب';
        break;
      default:
        color = Colors.grey;
        label = 'غير محدد';
    }
    
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
      decoration: BoxDecoration(
        color: color.withOpacity(0.2),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: color),
      ),
      child: Text(
        label,
        style: TextStyle(
          fontSize: 12,
          fontWeight: FontWeight.bold,
          color: color,
        ),
      ),
    );
  }

  // تنسيق التاريخ
  String _formatDate(DateTime date) {
    final List<String> arabicMonths = [
      'يناير', 'فبراير', 'مارس', 'إبريل', 'مايو', 'يونيو',
      'يوليو', 'أغسطس', 'سبتمبر', 'أكتوبر', 'نوفمبر', 'ديسمبر'
    ];
    
    return '${date.day} ${arabicMonths[date.month - 1]} ${date.year}';
  }

  // حذف حدث تاريخي
  Future<void> _deleteEvent(HistoricalEvent event) async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('تأكيد الحذف'),
        content: Text('هل أنت متأكد من حذف الحدث "${event.title}"؟'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('إلغاء'),
          ),
          TextButton(
            onPressed: () => Navigator.pop(context, true),
            child: const Text('حذف', style: TextStyle(color: Colors.red)),
          ),
        ],
      ),
    );
    
    if (confirmed == true) {
      final databaseService = Provider.of<DatabaseService>(context, listen: false);
      await databaseService.deleteEvent(event.id);
      
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('تم حذف الحدث بنجاح'),
          backgroundColor: Colors.green,
        ),
      );
      
      _loadEvents();
    }
  }
}
