import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../services/text_recognition_service.dart';
import '../services/database_service.dart';
import '../widgets/text_recognition_tester.dart';

/// شاشة اختبار الذكاء الاصطناعي
/// تتيح للمستخدم اختبار وظائف التعرف على النصوص من الصور
class AITestScreen extends StatelessWidget {
  const AITestScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('اختبار الذكاء الاصطناعي'),
        centerTitle: true,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // شرح الشاشة
            const Card(
              child: Padding(
                padding: EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'اختبار التعرف على النصوص من الصور',
                      style: TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    SizedBox(height: 8),
                    Text(
                      'هذه الشاشة تتيح لك اختبار قدرة التطبيق على التعرف على النصوص من الصور واستخراج الأحداث التاريخية منها.',
                      style: TextStyle(fontSize: 14),
                    ),
                    SizedBox(height: 8),
                    Text(
                      'يمكنك التقاط صورة أو اختيارها من المعرض، ثم معالجتها لاستخراج النص والحدث التاريخي.',
                      style: TextStyle(fontSize: 14),
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 16),
            
            // ويدجت اختبار التعرف على النصوص
            const TextRecognitionTester(),
          ],
        ),
      ),
    );
  }
}
