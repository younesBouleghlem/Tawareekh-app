import 'dart:io';
import 'package:flutter/material.dart';
import 'package:google_mlkit_text_recognition/google_mlkit_text_recognition.dart';
import 'package:image_picker/image_picker.dart';
import 'package:uuid/uuid.dart';
import '../models/event_model.dart';

/// خدمة التعرف على النصوص من الصور
/// تستخدم Google ML Kit للتعرف الضوئي على النصوص (OCR) بدون إنترنت
class TextRecognitionService {
  /// محرك التعرف على النصوص العربية
  final textRecognizer = TextRecognizer(script: TextRecognitionScript.arabic);
  
  /// أداة التقاط الصور
  final ImagePicker _picker = ImagePicker();
  
  /// التقاط صورة من الكاميرا
  /// يفتح الكاميرا ويسمح للمستخدم بالتقاط صورة
  /// يعيد ملف الصورة إذا تم التقاطها، أو null إذا تم إلغاء العملية
  Future<File?> captureImage() async {
    try {
      final XFile? photo = await _picker.pickImage(
        source: ImageSource.camera,
        imageQuality: 80, // تقليل جودة الصورة لتحسين الأداء
        preferredCameraDevice: CameraDevice.rear, // استخدام الكاميرا الخلفية
      );
      if (photo == null) return null;
      return File(photo.path);
    } catch (e) {
      print('خطأ في التقاط الصورة: $e');
      return null;
    }
  }
  
  /// اختيار صورة من المعرض
  /// يفتح معرض الصور ويسمح للمستخدم باختيار صورة
  /// يعيد ملف الصورة إذا تم اختيارها، أو null إذا تم إلغاء العملية
  Future<File?> pickImage() async {
    try {
      final XFile? image = await _picker.pickImage(
        source: ImageSource.gallery,
        imageQuality: 80, // تقليل جودة الصورة لتحسين الأداء
      );
      if (image == null) return null;
      return File(image.path);
    } catch (e) {
      print('خطأ في اختيار الصورة: $e');
      return null;
    }
  }
  
  /// التعرف على النص من الصورة
  /// يستخدم Google ML Kit للتعرف على النص في الصورة
  /// يعيد كائن RecognizedText الذي يحتوي على النص المتعرف عليه
  Future<RecognizedText> processImage(File imageFile) async {
    try {
      final inputImage = InputImage.fromFile(imageFile);
      return await textRecognizer.processImage(inputImage);
    } catch (e) {
      print('خطأ في معالجة الصورة: $e');
      rethrow; // إعادة رمي الاستثناء ليتم التعامل معه في المستوى الأعلى
    }
  }
  
  /// استخراج التاريخ والحدث من النص المتعرف عليه
  /// يحلل النص المتعرف عليه لاستخراج التاريخ والعنوان والوصف
  /// يعيد كائن HistoricalEvent إذا تم استخراج التاريخ والعنوان بنجاح، أو null إذا فشلت العملية
  Future<HistoricalEvent?> extractEventFromText(RecognizedText recognizedText) async {
    // النص الكامل المتعرف عليه
    final String text = recognizedText.text;
    
    if (text.isEmpty) {
      print('النص المتعرف عليه فارغ');
      return null;
    }
    
    print('النص المتعرف عليه: $text');
    
    // محاولة استخراج التاريخ
    DateTime? date;
    String title = '';
    String description = '';
    
    // البحث عن نمط التاريخ (مثل: 12/05/2023 أو 12-05-2023 أو 12.05.2023)
    final RegExp dateRegex = RegExp(r'(\d{1,2})[/.-](\d{1,2})[/.-](\d{4})');
    final dateMatch = dateRegex.firstMatch(text);
    
    if (dateMatch != null) {
      try {
        final day = int.parse(dateMatch.group(1)!);
        final month = int.parse(dateMatch.group(2)!);
        final year = int.parse(dateMatch.group(3)!);
        
        // التحقق من صحة التاريخ
        if (day > 0 && day <= 31 && month > 0 && month <= 12 && year >= 1000 && year <= 2100) {
          date = DateTime(year, month, day);
          
          // استخراج العنوان والوصف
          final textWithoutDate = text.replaceAll(dateMatch.group(0)!, '').trim();
          final lines = textWithoutDate.split('\n');
          
          if (lines.isNotEmpty) {
            title = lines[0].trim();
            if (lines.length > 1) {
              description = lines.sublist(1).join('\n').trim();
            }
          }
        } else {
          print('تاريخ غير صالح: ${dateMatch.group(0)}');
        }
      } catch (e) {
        print('خطأ في استخراج التاريخ: $e');
      }
    } else {
      // البحث عن نمط التاريخ بالكلمات العربية
      final arabicMonths = [
        'يناير', 'فبراير', 'مارس', 'إبريل', 'مايو', 'يونيو',
        'يوليو', 'أغسطس', 'سبتمبر', 'أكتوبر', 'نوفمبر', 'ديسمبر'
      ];
      
      for (int i = 0; i < arabicMonths.length; i++) {
        final month = arabicMonths[i];
        final monthRegex = RegExp(r'(\d{1,2})\s+' + month + r'\s+(\d{4})');
        final monthMatch = monthRegex.firstMatch(text);
        
        if (monthMatch != null) {
          try {
            final day = int.parse(monthMatch.group(1)!);
            final year = int.parse(monthMatch.group(2)!);
            
            // التحقق من صحة التاريخ
            if (day > 0 && day <= 31 && year >= 1000 && year <= 2100) {
              date = DateTime(year, i + 1, day);
              
              // استخراج العنوان والوصف
              final textWithoutDate = text.replaceAll(monthMatch.group(0)!, '').trim();
              final lines = textWithoutDate.split('\n');
              
              if (lines.isNotEmpty) {
                title = lines[0].trim();
                if (lines.length > 1) {
                  description = lines.sublist(1).join('\n').trim();
                }
              }
              
              break;
            }
          } catch (e) {
            print('خطأ في استخراج التاريخ بالكلمات العربية: $e');
          }
        }
      }
    }
    
    // إذا لم يتم العثور على تاريخ، نحاول استخراج العنوان والوصف فقط
    if (date == null) {
      final lines = text.split('\n');
      if (lines.isNotEmpty) {
        title = lines[0].trim();
        if (lines.length > 1) {
          description = lines.sublist(1).join('\n').trim();
        }
        
        // استخدام التاريخ الحالي كافتراضي
        date = DateTime.now();
        
        print('لم يتم العثور على تاريخ، استخدام التاريخ الحالي');
      }
    }
    
    if (date != null && title.isNotEmpty) {
      // تحديد مستوى الصعوبة بناءً على طول الوصف
      int difficulty = 1; // افتراضي: سهل
      
      if (description.length > 200) {
        difficulty = 3; // صعب
      } else if (description.length > 100) {
        difficulty = 2; // متوسط
      }
      
      return HistoricalEvent(
        id: const Uuid().v4(),
        date: date,
        title: title,
        description: description,
        difficulty: difficulty,
      );
    }
    
    print('فشل في استخراج حدث تاريخي من النص');
    return null;
  }
  
  /// تحليل الصورة واستخراج الحدث التاريخي
  /// يجمع بين معالجة الصورة واستخراج الحدث في خطوة واحدة
  /// يعيد كائن HistoricalEvent إذا نجحت العملية، أو null إذا فشلت
  Future<HistoricalEvent?> analyzeImage(File imageFile) async {
    try {
      final recognizedText = await processImage(imageFile);
      return await extractEventFromText(recognizedText);
    } catch (e) {
      print('خطأ في تحليل الصورة: $e');
      return null;
    }
  }
  
  /// توليد شرح مبسط للحدث التاريخي
  /// يستخدم بيانات الحدث لإنشاء شرح مبسط
  /// في الإصدار الحالي، يستخدم وصف الحدث نفسه مع بعض التنسيق
  String generateSimpleExplanation(HistoricalEvent event) {
    String explanation = 'في ${_formatDate(event.date)}، ${event.title}.';
    
    if (event.description.isNotEmpty) {
      explanation += '\n\n${event.description}';
      
      // إضافة بعض المعلومات الإضافية بناءً على نوع الحدث
      if (event.title.contains('حرب') || event.title.contains('معركة')) {
        explanation += '\n\nهذا الحدث يمثل صراعاً تاريخياً هاماً أثر على مجرى التاريخ.';
      } else if (event.title.contains('اكتشاف') || event.title.contains('اختراع')) {
        explanation += '\n\nهذا الاكتشاف كان له تأثير كبير على تطور البشرية والتكنولوجيا.';
      } else if (event.title.contains('استقلال') || event.title.contains('ثورة')) {
        explanation += '\n\nهذا الحدث يمثل نقطة تحول في تاريخ الشعوب والأمم.';
      }
    }
    
    return explanation;
  }
  
  /// تنسيق التاريخ بالعربية
  /// يحول كائن DateTime إلى نص بتنسيق عربي (مثل: 15 مايو 1948)
  String _formatDate(DateTime date) {
    final List<String> arabicMonths = [
      'يناير', 'فبراير', 'مارس', 'إبريل', 'مايو', 'يونيو',
      'يوليو', 'أغسطس', 'سبتمبر', 'أكتوبر', 'نوفمبر', 'ديسمبر'
    ];
    
    return '${date.day} ${arabicMonths[date.month - 1]} ${date.year}';
  }
  
  /// تحرير الموارد عند الانتهاء
  /// يجب استدعاء هذه الدالة عند الانتهاء من استخدام الخدمة
  void dispose() {
    textRecognizer.close();
  }
}
