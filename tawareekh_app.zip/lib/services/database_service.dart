import 'dart:async';
import 'package:flutter/material.dart';
import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';
import '../models/event_model.dart';

/// خدمة قاعدة البيانات
/// تتعامل مع تخزين واسترجاع الأحداث التاريخية وإحصائيات المستخدم
class DatabaseService extends ChangeNotifier {
  static Database? _database;
  
  // اسم قاعدة البيانات
  final String _databaseName = 'tawareekh.db';
  
  // إصدار قاعدة البيانات
  final int _databaseVersion = 1;
  
  // أسماء الجداول
  final String _eventsTable = 'events';
  final String _userStatsTable = 'user_stats';
  
  // الحصول على مثيل قاعدة البيانات
  Future<Database> get database async {
    if (_database != null) return _database!;
    
    _database = await _initDatabase();
    return _database!;
  }
  
  // تهيئة قاعدة البيانات
  Future<Database> _initDatabase() async {
    final databasePath = await getDatabasesPath();
    final path = join(databasePath, _databaseName);
    
    return await openDatabase(
      path,
      version: _databaseVersion,
      onCreate: _onCreate,
    );
  }
  
  // إنشاء جداول قاعدة البيانات
  Future<void> _onCreate(Database db, int version) async {
    // جدول الأحداث التاريخية
    await db.execute('''
      CREATE TABLE $_eventsTable (
        id TEXT PRIMARY KEY,
        title TEXT NOT NULL,
        description TEXT,
        date INTEGER NOT NULL,
        difficulty INTEGER NOT NULL
      )
    ''');
    
    // جدول إحصائيات المستخدم
    await db.execute('''
      CREATE TABLE $_userStatsTable (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        score INTEGER NOT NULL,
        streak_days INTEGER NOT NULL,
        last_played_date INTEGER NOT NULL,
        correct_answers INTEGER NOT NULL,
        wrong_answers INTEGER NOT NULL
      )
    ''');
    
    // إدخال بيانات افتراضية لإحصائيات المستخدم
    await db.insert(
      _userStatsTable,
      {
        'score': 0,
        'streak_days': 0,
        'last_played_date': DateTime.now().millisecondsSinceEpoch,
        'correct_answers': 0,
        'wrong_answers': 0,
      },
    );
  }
  
  // إضافة حدث تاريخي جديد
  Future<void> addEvent(HistoricalEvent event) async {
    final db = await database;
    
    await db.insert(
      _eventsTable,
      {
        'id': event.id,
        'title': event.title,
        'description': event.description,
        'date': event.date.millisecondsSinceEpoch,
        'difficulty': event.difficulty,
      },
      conflictAlgorithm: ConflictAlgorithm.replace,
    );
    
    notifyListeners();
  }
  
  // الحصول على جميع الأحداث التاريخية
  Future<List<HistoricalEvent>> getEvents() async {
    final db = await database;
    
    final List<Map<String, dynamic>> maps = await db.query(_eventsTable);
    
    return List.generate(maps.length, (i) {
      return HistoricalEvent(
        id: maps[i]['id'],
        title: maps[i]['title'],
        description: maps[i]['description'],
        date: DateTime.fromMillisecondsSinceEpoch(maps[i]['date']),
        difficulty: maps[i]['difficulty'],
      );
    });
  }
  
  // الحصول على الأحداث التاريخية حسب مستوى الصعوبة
  Future<List<HistoricalEvent>> getEventsByDifficulty(int difficulty) async {
    final db = await database;
    
    final List<Map<String, dynamic>> maps = await db.query(
      _eventsTable,
      where: 'difficulty = ?',
      whereArgs: [difficulty],
    );
    
    return List.generate(maps.length, (i) {
      return HistoricalEvent(
        id: maps[i]['id'],
        title: maps[i]['title'],
        description: maps[i]['description'],
        date: DateTime.fromMillisecondsSinceEpoch(maps[i]['date']),
        difficulty: maps[i]['difficulty'],
      );
    });
  }
  
  // الحصول على حدث تاريخي بواسطة المعرف
  Future<HistoricalEvent?> getEventById(String id) async {
    final db = await database;
    
    final List<Map<String, dynamic>> maps = await db.query(
      _eventsTable,
      where: 'id = ?',
      whereArgs: [id],
    );
    
    if (maps.isEmpty) return null;
    
    return HistoricalEvent(
      id: maps[0]['id'],
      title: maps[0]['title'],
      description: maps[0]['description'],
      date: DateTime.fromMillisecondsSinceEpoch(maps[0]['date']),
      difficulty: maps[0]['difficulty'],
    );
  }
  
  // تحديث حدث تاريخي
  Future<void> updateEvent(HistoricalEvent event) async {
    final db = await database;
    
    await db.update(
      _eventsTable,
      {
        'title': event.title,
        'description': event.description,
        'date': event.date.millisecondsSinceEpoch,
        'difficulty': event.difficulty,
      },
      where: 'id = ?',
      whereArgs: [event.id],
    );
    
    notifyListeners();
  }
  
  // حذف حدث تاريخي
  Future<void> deleteEvent(String id) async {
    final db = await database;
    
    await db.delete(
      _eventsTable,
      where: 'id = ?',
      whereArgs: [id],
    );
    
    notifyListeners();
  }
  
  // الحصول على إحصائيات المستخدم
  Future<Map<String, dynamic>> getUserStats() async {
    final db = await database;
    
    final List<Map<String, dynamic>> maps = await db.query(_userStatsTable);
    
    if (maps.isEmpty) {
      // إذا لم تكن هناك إحصائيات، إنشاء إحصائيات افتراضية
      await db.insert(
        _userStatsTable,
        {
          'score': 0,
          'streak_days': 0,
          'last_played_date': DateTime.now().millisecondsSinceEpoch,
          'correct_answers': 0,
          'wrong_answers': 0,
        },
      );
      
      return {
        'score': 0,
        'streak_days': 0,
        'last_played_date': DateTime.now().millisecondsSinceEpoch,
        'correct_answers': 0,
        'wrong_answers': 0,
      };
    }
    
    return maps[0];
  }
  
  // تحديث إحصائيات المستخدم
  Future<void> updateUserStats(Map<String, dynamic> stats) async {
    final db = await database;
    
    await db.update(
      _userStatsTable,
      stats,
      where: 'id = 1',
    );
    
    notifyListeners();
  }
  
  // تحديث النقاط
  Future<void> updateScore(bool isCorrect) async {
    final db = await database;
    
    // الحصول على الإحصائيات الحالية
    final stats = await getUserStats();
    
    // تحديث النقاط والإجابات
    int score = stats['score'];
    int correctAnswers = stats['correct_answers'];
    int wrongAnswers = stats['wrong_answers'];
    
    if (isCorrect) {
      score += 10;
      correctAnswers++;
    } else {
      wrongAnswers++;
    }
    
    // تحديث الإحصائيات
    await db.update(
      _userStatsTable,
      {
        'score': score,
        'correct_answers': correctAnswers,
        'wrong_answers': wrongAnswers,
      },
      where: 'id = 1',
    );
    
    notifyListeners();
  }
  
  // تحديث الحماسة (streak)
  Future<void> updateStreak() async {
    final db = await database;
    
    // الحصول على الإحصائيات الحالية
    final stats = await getUserStats();
    
    // تحديث الحماسة
    final lastPlayedDate = DateTime.fromMillisecondsSinceEpoch(stats['last_played_date']);
    final now = DateTime.now();
    
    // التحقق مما إذا كان اليوم هو نفس يوم آخر لعب
    final isSameDay = lastPlayedDate.year == now.year &&
                      lastPlayedDate.month == now.month &&
                      lastPlayedDate.day == now.day;
    
    // التحقق مما إذا كان اليوم هو اليوم التالي ليوم آخر لعب
    final isNextDay = lastPlayedDate.year == now.year &&
                      lastPlayedDate.month == now.month &&
                      lastPlayedDate.day == now.day - 1;
    
    int streakDays = stats['streak_days'];
    
    if (!isSameDay) {
      if (isNextDay) {
        // إذا كان اليوم هو اليوم التالي، زيادة الحماسة
        streakDays++;
      } else {
        // إذا كان هناك فجوة، إعادة تعيين الحماسة
        streakDays = 1;
      }
      
      // تحديث تاريخ آخر لعب والحماسة
      await db.update(
        _userStatsTable,
        {
          'streak_days': streakDays,
          'last_played_date': now.millisecondsSinceEpoch,
        },
        where: 'id = 1',
      );
      
      notifyListeners();
    }
  }
  
  // إضافة نقاط إضافية
  Future<void> addBonusPoints(int points) async {
    final db = await database;
    
    // الحصول على الإحصائيات الحالية
    final stats = await getUserStats();
    
    // تحديث النقاط
    int score = stats['score'] + points;
    
    // تحديث الإحصائيات
    await db.update(
      _userStatsTable,
      {
        'score': score,
      },
      where: 'id = 1',
    );
    
    notifyListeners();
  }
  
  // الحصول على مكافأة الحماسة
  Future<int> getStreakBonus() async {
    final stats = await getUserStats();
    final streakDays = stats['streak_days'];
    
    // حساب مكافأة الحماسة
    // 5 نقاط لكل 3 أيام متتالية، بحد أقصى 50 نقطة
    int bonus = (streakDays ~/ 3) * 5;
    return bonus > 50 ? 50 : bonus;
  }
  
  // إعادة تعيين قاعدة البيانات (للاختبار فقط)
  Future<void> resetDatabase() async {
    final databasePath = await getDatabasesPath();
    final path = join(databasePath, _databaseName);
    
    await deleteDatabase(path);
    _database = null;
    
    await database;
    
    notifyListeners();
  }
}
