class HistoricalEvent {
  final String id;
  final DateTime date;
  final String title;
  final String description;
  final int difficulty; // 1: سهل، 2: متوسط، 3: صعب

  HistoricalEvent({
    required this.id,
    required this.date,
    required this.title,
    required this.description,
    this.difficulty = 1,
  });

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'date': date.millisecondsSinceEpoch,
      'title': title,
      'description': description,
      'difficulty': difficulty,
    };
  }

  factory HistoricalEvent.fromMap(Map<String, dynamic> map) {
    return HistoricalEvent(
      id: map['id'],
      date: DateTime.fromMillisecondsSinceEpoch(map['date']),
      title: map['title'],
      description: map['description'],
      difficulty: map['difficulty'] ?? 1,
    );
  }
}
