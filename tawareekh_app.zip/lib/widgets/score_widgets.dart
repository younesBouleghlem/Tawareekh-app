import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../services/database_service.dart';
import '../utils/app_theme.dart';

/// ويدجت عرض الحماسة
/// يعرض عدد أيام الحماسة المتتالية بشكل جذاب
class StreakWidget extends StatelessWidget {
  final int streakDays;
  final bool showLabel;
  final double size;

  const StreakWidget({
    Key? key,
    required this.streakDays,
    this.showLabel = true,
    this.size = 1.0,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        Container(
          padding: EdgeInsets.all(8 * size),
          decoration: BoxDecoration(
            color: _getStreakColor().withOpacity(0.2),
            borderRadius: BorderRadius.circular(12 * size),
            border: Border.all(color: _getStreakColor()),
          ),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(
                Icons.local_fire_department,
                color: _getStreakColor(),
                size: 24 * size,
              ),
              SizedBox(width: 4 * size),
              Text(
                '$streakDays',
                style: TextStyle(
                  fontSize: 16 * size,
                  fontWeight: FontWeight.bold,
                  color: _getStreakColor(),
                ),
              ),
            ],
          ),
        ),
        if (showLabel) ...[
          const SizedBox(height: 4),
          Text(
            'أيام الحماسة',
            style: TextStyle(
              fontSize: 12 * size,
              color: Colors.grey,
            ),
          ),
        ],
      ],
    );
  }

  // الحصول على لون الحماسة بناءً على عدد الأيام
  Color _getStreakColor() {
    if (streakDays >= 30) {
      return Colors.purple; // حماسة ممتازة
    } else if (streakDays >= 14) {
      return Colors.red; // حماسة جيدة جداً
    } else if (streakDays >= 7) {
      return Colors.orange; // حماسة جيدة
    } else if (streakDays >= 3) {
      return Colors.amber; // حماسة متوسطة
    } else {
      return Colors.green; // حماسة مبتدئة
    }
  }
}

/// ويدجت عرض النقاط
/// يعرض نقاط المستخدم بشكل جذاب
class ScoreWidget extends StatelessWidget {
  final int score;
  final bool showLabel;
  final double size;

  const ScoreWidget({
    Key? key,
    required this.score,
    this.showLabel = true,
    this.size = 1.0,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        Container(
          padding: EdgeInsets.all(8 * size),
          decoration: BoxDecoration(
            color: AppTheme.primaryColor.withOpacity(0.2),
            borderRadius: BorderRadius.circular(12 * size),
            border: Border.all(color: AppTheme.primaryColor),
          ),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(
                Icons.emoji_events,
                color: AppTheme.primaryColor,
                size: 24 * size,
              ),
              SizedBox(width: 4 * size),
              Text(
                '$score',
                style: TextStyle(
                  fontSize: 16 * size,
                  fontWeight: FontWeight.bold,
                  color: AppTheme.primaryColor,
                ),
              ),
            ],
          ),
        ),
        if (showLabel) ...[
          const SizedBox(height: 4),
          Text(
            'النقاط',
            style: TextStyle(
              fontSize: 12 * size,
              color: Colors.grey,
            ),
          ),
        ],
      ],
    );
  }
}

/// ويدجت عرض مكافأة الحماسة
/// يعرض مكافأة الحماسة اليومية ويتيح للمستخدم المطالبة بها
class StreakBonusWidget extends StatefulWidget {
  const StreakBonusWidget({Key? key}) : super(key: key);

  @override
  State<StreakBonusWidget> createState() => _StreakBonusWidgetState();
}

class _StreakBonusWidgetState extends State<StreakBonusWidget> {
  bool _isLoading = false;
  bool _isClaimed = false;
  int _bonus = 0;

  @override
  void initState() {
    super.initState();
    _loadBonus();
  }

  // تحميل مكافأة الحماسة
  Future<void> _loadBonus() async {
    setState(() {
      _isLoading = true;
    });

    final databaseService = Provider.of<DatabaseService>(context, listen: false);
    final bonus = await databaseService.getStreakBonus();

    setState(() {
      _bonus = bonus;
      _isLoading = false;
    });
  }

  // المطالبة بمكافأة الحماسة
  Future<void> _claimBonus() async {
    if (_bonus <= 0 || _isClaimed) return;

    setState(() {
      _isLoading = true;
    });

    final databaseService = Provider.of<DatabaseService>(context, listen: false);
    await databaseService.addBonusPoints(_bonus);

    setState(() {
      _isClaimed = true;
      _isLoading = false;
    });

    // إظهار رسالة نجاح
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('تمت إضافة $_bonus نقطة كمكافأة للحماسة!'),
        backgroundColor: Colors.green,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    if (_isLoading) {
      return const Center(child: CircularProgressIndicator());
    }

    if (_bonus <= 0) {
      return const SizedBox(); // لا توجد مكافأة متاحة
    }

    return Card(
      elevation: 2,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12),
      ),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            Row(
              children: [
                const Icon(Icons.local_fire_department, color: Colors.orange),
                const SizedBox(width: 8),
                const Text(
                  'مكافأة الحماسة اليومية',
                  style: TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const Spacer(),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                  decoration: BoxDecoration(
                    color: AppTheme.primaryColor.withOpacity(0.2),
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Text(
                    '+$_bonus',
                    style: const TextStyle(
                      fontSize: 14,
                      fontWeight: FontWeight.bold,
                      color: AppTheme.primaryColor,
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 8),
            const Text(
              'استمر في اللعب يومياً للحصول على المزيد من النقاط!',
              style: TextStyle(fontSize: 14),
            ),
            const SizedBox(height: 12),
            ElevatedButton(
              onPressed: _isClaimed ? null : _claimBonus,
              style: ElevatedButton.styleFrom(
                backgroundColor: _isClaimed ? Colors.grey : AppTheme.primaryColor,
                foregroundColor: Colors.white,
                minimumSize: const Size(double.infinity, 40),
              ),
              child: Text(_isClaimed ? 'تم المطالبة' : 'المطالبة بالمكافأة'),
            ),
          ],
        ),
      ),
    );
  }
}
