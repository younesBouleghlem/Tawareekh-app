import 'dart:io';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../services/text_recognition_service.dart';
import '../utils/app_theme.dart';
import '../models/event_model.dart';

/// ويدجت لاختبار خدمة التعرف على النصوص
/// يستخدم لاختبار وظائف التعرف على النصوص من الصور
class TextRecognitionTester extends StatefulWidget {
  const TextRecognitionTester({Key? key}) : super(key: key);

  @override
  State<TextRecognitionTester> createState() => _TextRecognitionTesterState();
}

class _TextRecognitionTesterState extends State<TextRecognitionTester> {
  File? _selectedImage;
  String _recognizedText = '';
  bool _isProcessing = false;
  HistoricalEvent? _extractedEvent;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('اختبار التعرف على النصوص'),
        centerTitle: true,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            // عرض الصورة المختارة
            Container(
              height: 200,
              decoration: BoxDecoration(
                color: Colors.grey[200],
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: Colors.grey),
              ),
              child: _selectedImage != null
                  ? ClipRRect(
                      borderRadius: BorderRadius.circular(12),
                      child: Image.file(
                        _selectedImage!,
                        fit: BoxFit.cover,
                      ),
                    )
                  : const Center(
                      child: Text(
                        'لم يتم اختيار صورة',
                        style: TextStyle(color: Colors.grey),
                      ),
                    ),
            ),
            const SizedBox(height: 16),
            
            // أزرار التقاط صورة أو اختيارها من المعرض
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                ElevatedButton.icon(
                  onPressed: _captureImage,
                  icon: const Icon(Icons.camera_alt),
                  label: const Text('التقاط صورة'),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: AppTheme.primaryColor,
                    foregroundColor: Colors.white,
                  ),
                ),
                ElevatedButton.icon(
                  onPressed: _pickImage,
                  icon: const Icon(Icons.photo_library),
                  label: const Text('اختيار من المعرض'),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: AppTheme.secondaryColor,
                    foregroundColor: Colors.white,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 16),
            
            // زر معالجة الصورة
            ElevatedButton(
              onPressed: _selectedImage != null && !_isProcessing
                  ? _processImage
                  : null,
              style: ElevatedButton.styleFrom(
                backgroundColor: AppTheme.primaryColor,
                foregroundColor: Colors.white,
                padding: const EdgeInsets.symmetric(vertical: 12),
              ),
              child: _isProcessing
                  ? const CircularProgressIndicator(color: Colors.white)
                  : const Text('معالجة الصورة'),
            ),
            const SizedBox(height: 24),
            
            // عرض النص المتعرف عليه
            if (_recognizedText.isNotEmpty) ...[
              const Text(
                'النص المتعرف عليه:',
                style: TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 8),
              Container(
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: Colors.grey[100],
                  borderRadius: BorderRadius.circular(8),
                  border: Border.all(color: Colors.grey),
                ),
                child: Text(_recognizedText),
              ),
              const SizedBox(height: 24),
            ],
            
            // عرض الحدث المستخرج
            if (_extractedEvent != null) ...[
              const Text(
                'الحدث المستخرج:',
                style: TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 8),
              Card(
                elevation: 2,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        _extractedEvent!.title,
                        style: const TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      const SizedBox(height: 8),
                      Row(
                        children: [
                          const Icon(Icons.calendar_today, size: 16, color: Colors.grey),
                          const SizedBox(width: 8),
                          Text(
                            _formatDate(_extractedEvent!.date),
                            style: const TextStyle(
                              fontSize: 14,
                              color: Colors.grey,
                            ),
                          ),
                        ],
                      ),
                      if (_extractedEvent!.description.isNotEmpty) ...[
                        const SizedBox(height: 8),
                        const Divider(),
                        Text(_extractedEvent!.description),
                      ],
                      const SizedBox(height: 8),
                      Row(
                        children: [
                          const Text('مستوى الصعوبة:'),
                          const SizedBox(width: 8),
                          _buildDifficultyBadge(_extractedEvent!.difficulty),
                        ],
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }

  // التقاط صورة من الكاميرا
  Future<void> _captureImage() async {
    final textRecognitionService =
        Provider.of<TextRecognitionService>(context, listen: false);
    
    final imageFile = await textRecognitionService.captureImage();
    if (imageFile != null) {
      setState(() {
        _selectedImage = imageFile;
        _recognizedText = '';
        _extractedEvent = null;
      });
    }
  }

  // اختيار صورة من المعرض
  Future<void> _pickImage() async {
    final textRecognitionService =
        Provider.of<TextRecognitionService>(context, listen: false);
    
    final imageFile = await textRecognitionService.pickImage();
    if (imageFile != null) {
      setState(() {
        _selectedImage = imageFile;
        _recognizedText = '';
        _extractedEvent = null;
      });
    }
  }

  // معالجة الصورة
  Future<void> _processImage() async {
    if (_selectedImage == null) return;
    
    setState(() {
      _isProcessing = true;
    });
    
    try {
      final textRecognitionService =
          Provider.of<TextRecognitionService>(context, listen: false);
      
      // التعرف على النص
      final recognizedText = await textRecognitionService.processImage(_selectedImage!);
      
      // استخراج الحدث
      final event = await textRecognitionService.extractEventFromText(recognizedText);
      
      setState(() {
        _recognizedText = recognizedText.text;
        _extractedEvent = event;
        _isProcessing = false;
      });
    } catch (e) {
      setState(() {
        _recognizedText = 'حدث خطأ أثناء معالجة الصورة: $e';
        _isProcessing = false;
      });
    }
  }

  // تنسيق التاريخ
  String _formatDate(DateTime date) {
    final List<String> arabicMonths = [
      'يناير', 'فبراير', 'مارس', 'إبريل', 'مايو', 'يونيو',
      'يوليو', 'أغسطس', 'سبتمبر', 'أكتوبر', 'نوفمبر', 'ديسمبر'
    ];
    
    return '${date.day} ${arabicMonths[date.month - 1]} ${date.year}';
  }

  // بناء شارة مستوى الصعوبة
  Widget _buildDifficultyBadge(int difficulty) {
    Color color;
    String label;
    
    switch (difficulty) {
      case 1:
        color = Colors.green;
        label = 'سهل';
        break;
      case 2:
        color = Colors.orange;
        label = 'متوسط';
        break;
      case 3:
        color = Colors.red;
        label = 'صعب';
        break;
      default:
        color = Colors.grey;
        label = 'غير محدد';
    }
    
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
      decoration: BoxDecoration(
        color: color.withOpacity(0.2),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: color),
      ),
      child: Text(
        label,
        style: TextStyle(
          fontSize: 12,
          fontWeight: FontWeight.bold,
          color: color,
        ),
      ),
    );
  }
}
